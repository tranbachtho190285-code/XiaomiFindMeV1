package com.example.xiaomifindme

import android.app.*
import android.content.Context
import android.content.Intent
import android.media.*
import android.os.*
import android.speech.*
import android.speech.tts.TextToSpeech
import android.speech.RecognitionListener
import java.util.Locale

class ListenService : Service() {
    private lateinit var recognizer: SpeechRecognizer
    private lateinit var audio: AudioManager
    private var tts: TextToSpeech? = null
    private var alarmPlayer: MediaPlayer? = null
    private var vibrator: Vibrator? = null

    override fun onCreate() {
        super.onCreate()
        createChannel()
        startForeground(1, notification("Đang chờ: Alo, mày đâu rồi Xiaomi"))
        audio = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        vibrator = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        tts = TextToSpeech(this) { tts?.language = Locale("vi", "VN") }

        recognizer = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer.setRecognitionListener(object : RecognitionListener {
            override fun onResults(results: Bundle) {
                val text = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.joinToString(" ")?.lowercase(Locale.getDefault()) ?: ""
                if (text.contains("mày đâu rồi") || text.contains("may dau roi")) {
                    findMe()
                } else if (text.contains("dừng") || text.contains("dung")) {
                    stopFindMe()
                }
                listenAgain()
            }
            override fun onError(error: Int) { listenAgain() }
            override fun onReadyForSpeech(p: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(r: Float) {}
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(b: Bundle?) {}
            override fun onEvent(t: Int, p: Bundle?) {}
        })
        listenAgain()
    }

    private fun listenAgain() {
        Handler(Looper.getMainLooper()).postDelayed({
            try {
                val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, "vi-VN")
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                        RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                }
                recognizer.startListening(intent)
            } catch (_: Exception) {}
        }, 250)
    }

    private fun findMe() {
        val max = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        audio.setStreamVolume(AudioManager.STREAM_MUSIC, max, 0)

        val uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
        alarmPlayer?.release()
        alarmPlayer = MediaPlayer.create(this, uri)?.apply {
            isLooping = true
            setVolume(1f, 1f)
            start()
        }
        tts?.speak("Tôi đây! Tôi đây! Hãy tìm tôi!", TextToSpeech.QUEUE_FLUSH, null, "find")
        vibrator?.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 500, 300), 0))
    }

    private fun stopFindMe() {
        alarmPlayer?.stop()
        alarmPlayer?.release()
        alarmPlayer = null
        vibrator?.cancel()
        tts?.stop()
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val c = NotificationChannel("findme", "Xiaomi Find Me",
                NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(c)
        }
    }

    private fun notification(text: String): Notification =
        Notification.Builder(this, "findme")
            .setContentTitle("Xiaomi Find Me")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setOngoing(true)
            .build()

    override fun onDestroy() {
        stopFindMe()
        recognizer.destroy()
        tts?.shutdown()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?) = null
}
