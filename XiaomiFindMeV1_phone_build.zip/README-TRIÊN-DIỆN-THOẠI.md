XIAOMI FIND ME V1

Mục tiêu:
- Nói "Alo, mày đâu rồi Xiaomi?" (bản V1 nhận phần "mày đâu rồi")
- Đặt âm lượng nhạc lên mức tối đa mà Android cho phép
- Phát chuông báo lặp
- Rung
- Nói "Dừng" để tắt

QUAN TRỌNG:
Bản này là mã nguồn Android để build ngay trên điện thoại bằng môi trường Android build hỗ trợ Gradle.
Android/HyperOS có giới hạn đối với microphone chạy nền và màn hình khóa. V1 không vượt qua các giới hạn bảo mật đó.

CẤP QUYỀN TRÊN XIAOMI:
1. Microphone: Cho phép.
2. Notifications: Cho phép nếu hệ thống hỏi.
3. Settings > Apps > Xiaomi Find Me > Battery: chọn "No restrictions" nếu có.
4. Cho phép "Autostart" nếu HyperOS hiển thị mục này.
5. Không tắt thông báo foreground service.

Để có wake-word thật sự ("Alo...") ổn định khi khóa màn hình, bản V2 nên dùng engine wake-word chuyên dụng/foreground service phù hợp Android thay vì SpeechRecognizer thuần.
